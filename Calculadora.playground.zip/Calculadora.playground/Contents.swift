import UIKit
func calculadora(opcion: Int, numero1: Double, numero2: Double){
print("Bienvenido:\r 1) SUMA\r 2) RESTA\r 3)MULTIPLICACION\r 4)DIVISION")
    
    calculadora(opcion: <#T##Int#>, numero1: <#T##Double#>, numero2: <#T##Double#>)
    
    switch opcion {
    case 1:
        
            print("El resultado de la suma es (suma (numero1: numero1, numero2: numero2))")
    case 2:
        
        print("El resultado de la resta es (suma (numero1: numero1, numero2: numero2))")
    case 3:
        
        print("El resultado de la multiplicacion es (suma (numero1: numero1, numero2: numero2))")
    case 4:
        
        if numero2 == 0 {
            print("no es posible dividir entre 0, ingrese un numero mayor")
       1 } else {
            
            print("El resultado de la division es (suma (numero1: numero1, numero2: numero2))")
        }
    default:
        
        print("Ingrese una opcion del 1 al 4")
    }
    
    
    func Sum (numero1: Double , numero2: Double) -> Double {
        var result = numero1 + numero2
        return result
    }


    func Rest (numero1: Double , numero2: Double) -> Double {
        
        var result = numero1 - numero2
        return result
    }

    func Mult (numero1: Double , numero2: Double) -> Double {
        
        var result = numero1 * numero2
        return result
    }

    func Div (numero1: Double , numero2: Double) -> Double {
        
        var result = numero1 / numero2
        return result
    }

}
